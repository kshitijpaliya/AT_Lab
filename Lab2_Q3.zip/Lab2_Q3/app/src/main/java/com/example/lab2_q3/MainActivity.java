package com.example.lab2_q3;

import android.os.Bundle;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.util.Base64;

public class MainActivity extends AppCompatActivity {
    private Button encrybutton;
    private EditText encryptedText; // TextView to display encrypted text
    private TextView displayencrypted;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        encrybutton = findViewById(R.id.button); // Login Button
        encryptedText = findViewById(R.id.editTextText); // Encrypted text view
        displayencrypted = findViewById(R.id.textView3);

        encrybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String encrypt = encryptedText.getText().toString().trim();
                // Get user input from EditTex
                String encryptedText = encodeToBase64(encrypt);
                displayencrypted.setText("Encrypted Password: " + encryptedText); // Display encrypted text
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private String encodeToBase64(String text) {
        // Convert text to bytes and encode it to Base64
        return Base64.encodeToString(text.getBytes(), Base64.NO_WRAP);
    }
}