package com.example.lab1_q1;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.TextView;
import androidx.core.graphics.Insets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    private RadioGroup radioGroup;
    private TextView selectedTextView;
    private TextView selectedText;
    private CheckBox checkBox5, checkBox6, checkBox7;
    private Switch switch1;
    private Spinner ratingSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        selectedTextView = findViewById(R.id.selectedText);
        selectedText = findViewById(R.id.selectedText2);
        checkBox5 = findViewById(R.id.checkBox5);
        checkBox6 = findViewById(R.id.checkBox6);
        checkBox7 = findViewById(R.id.checkBox7);

        checkBox5.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectedText());
        checkBox6.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectedText());
        checkBox7.setOnCheckedChangeListener((buttonView, isChecked) -> updateSelectedText());

        switch1 = findViewById(R.id.switch1);

        ratingSpinner = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.rating_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ratingSpinner.setAdapter(adapter);


        // Set a listener to handle changes when a radio button is selected
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            // Get the selected RadioButton by its ID
            RadioButton radioButton = findViewById(checkedId);
            selectedTextView.setText("Selected: " + radioButton.getText());
            // Display a Toast message with the text of the selected RadioButton
            Toast.makeText(MainActivity.this, "Selected Radio Button is: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
        });

        //        Button viewMoreStatsButton = findViewById(R.id.button);
//        viewMoreStatsButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "10 Rs ki Pepsi, Kohli Bhaiya Sexxy...", Toast.LENGTH_SHORT).show();
//            }
//        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Check the switch state and show the appropriate Toast message
            if (isChecked) {
                // Switch is ON, display "Food Quality: Bad"
                Toast.makeText(MainActivity.this, "Food Quality: Bad", Toast.LENGTH_SHORT).show();
            } else {
                // Switch is OFF, display "Food Quality: Good"
                Toast.makeText(MainActivity.this, "Food Quality: Good", Toast.LENGTH_SHORT).show();
            }
        });

        ratingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Get the selected rating
                String selectedRating = parentView.getItemAtPosition(position).toString();
                // Display a Toast with the selected rating
                Toast.makeText(MainActivity.this, "Selected Rating: " + selectedRating, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Optionally, handle the case where nothing is selected
            }
        });
    }
    private void updateSelectedText() {
        StringBuilder selectedItems = new StringBuilder("Selected: ");
        if (checkBox5.isChecked()) {
            selectedItems.append("Apple ");
        }
        if (checkBox6.isChecked()) {
            selectedItems.append("Orange ");
        }
        if (checkBox7.isChecked()) {
            selectedItems.append("Mango ");
        }
        selectedText.setText(selectedItems.toString());
    }
}